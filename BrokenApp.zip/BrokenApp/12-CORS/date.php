<?php

echo date("M,d,Y h:i:s A") . "\n";

?>

