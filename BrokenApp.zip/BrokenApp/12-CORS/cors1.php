<?php

 header('Access-Control-Allow-Origin: *');
 echo date("M,d,Y h:i:s A") . "\n";

?>

