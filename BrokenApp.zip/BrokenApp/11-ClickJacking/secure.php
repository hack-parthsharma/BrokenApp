<?php

 header('X-Frame-Options: Deny');

 echo '<h1>Not Vulnerable To Click Jacking.</h1>';

?>
